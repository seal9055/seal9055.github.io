#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/fs.h>   
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/proc_fs.h>

struct proc_dir_entry* proc_entry = NULL;

static int s_open(struct inode *inode, struct file *file)
{
   	printk(KERN_ALERT "Device opened\n");
   	return 0;
}

static int s_release(struct inode *inode, struct file *file)
{
    printk(KERN_ALERT "All device's closed\n");
    return 0;
}

static ssize_t s_read(struct file *file, char __user *ubuf, size_t size, loff_t *offset)
{
	char message[40];

	strcpy(message, "Welcome to this kernel pwn series");
    
    if (raw_copy_to_user(ubuf, message, size) == 0) {
    	printk(KERN_ALERT "%ld bytes read by device\n", size);
    }
    else {
    	printk(KERN_ALERT "Some error occured in read\n");
    }
    
    return size;
}

static ssize_t s_write(struct file *file, const char __user *ubuf, size_t size, loff_t *offset)
{
	char buffer[40];

    if (raw_copy_from_user(buffer, ubuf, size) == 0) {
    	printk(KERN_ALERT "%ld bytes written to device\n", size);
    }
    else {
    	printk(KERN_ALERT "Some error occured in write\n");
    }
        
   	return size;
}

static const struct proc_ops fops = {
	.proc_open    = s_open,
   	.proc_read    = s_read,
   	.proc_write   = s_write,
   	.proc_release = s_release
};

static int __init init_func(void)
{
	proc_entry = proc_create("pwn_device", 0666, NULL, &fops);
    printk(KERN_ALERT "Module successfuly initialized\n");
    return 0;
}

static void __exit exit_func(void)
{
	if (proc_entry) {
		proc_remove(proc_entry);
	}
   	printk(KERN_ALERT "Module successfuly unloaded\n");
}

MODULE_LICENSE("GPL v2");
module_init(init_func);
module_exit(exit_func);
