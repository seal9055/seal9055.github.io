#!/bin/bash

pushd fs
find . -print0 | cpio --null -ov --format=newc | gzip -9 > ../initramfs.cpio.gz
popd

/usr/bin/qemu-system-x86_64 \
	-m 128M \
	-cpu kvm64,+smep,+smap \
	-kernel linux-5.8/arch/x86/boot/bzImage \
	-initrd $PWD/initramfs.cpio.gz \
	-nographic \
	-snapshot \
	-monitor none \
	-s \
	-append "console=ttyS0 kaslr quiet panic=1"
